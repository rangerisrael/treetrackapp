<?php

include_once 'mapfunction.php';



 insert_area();



?>
label