<?php


return [
	"db" => [
		"server" => "localhost",
		"dbname" => "id8331598_tretracking",
		"user" => "id8331598_root",
		"pass" => "capstone@2019",
	],
];


	