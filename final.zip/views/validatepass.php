<?php

	$admin="admin";


	echo password_hash($admin,PASSWORD_DEFAULT);

?>