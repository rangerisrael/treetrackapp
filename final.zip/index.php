<?php

header('location: views/testloginpage.php');