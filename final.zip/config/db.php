<?php
		$host="fdb25.localhost.com";
		$database="id8331598_tretracking";
		$user="id8331598_root";
		$pass="capstone@2019";

 

			  $pdo = new PDO("mysql:dbname={$database};host={$host};port={3306}", $user, $pass);

					if(!$pdo){
						die('connection not set correctly');
					}
?>